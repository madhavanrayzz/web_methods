from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

import base64
from email.mime.text import MIMEText

SCOPES = ["https://www.googleapis.com/auth/gmail.send"]

SUBJECT = "Security vulnerability report"

BODY = """Hi Team,

I have identified multiple potential security vulnerabilities on your application, including issues with high and medium severity impact.

Before sharing full technical details, I would like to confirm whether you have an active vulnerability disclosure or bug bounty program, and if rewards are provided for valid findings.

I’m happy to provide a detailed report and proof of concept once I have clarity on your disclosure process.

Looking forward to your response.

Thanks,
Madhavan
VAPT Researcher
"""


def gmail_auth():
    creds = None

    try:
        creds = Credentials.from_authorized_user_file(
            "token.json",
            SCOPES
        )
    except Exception:
        pass

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                "credentials.json",
                SCOPES
            )
            creds = flow.run_local_server(port=0)

        with open("token.json", "w") as token:
            token.write(creds.to_json())

    return build("gmail", "v1", credentials=creds)


def create_message(to_email):
    message = MIMEText(BODY)
    message["to"] = to_email
    message["subject"] = SUBJECT

    raw = base64.urlsafe_b64encode(
        message.as_bytes()
    ).decode()

    return {"raw": raw}


def main():
    service = gmail_auth()

    with open("contacts.txt", "r") as f:
        contacts = [
            line.strip()
            for line in f
            if line.strip()
        ]

    for email in contacts:
        service.users().messages().send(
            userId="me",
            body=create_message(email)
        ).execute()

        print(f"[+] Sent -> {email}")


if __name__ == "__main__":
    main()
